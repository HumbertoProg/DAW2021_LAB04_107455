from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse


from .models import *

# Visualização para adicionar ou remover produtos das listas de observação
@login_required(login_url='/login')
def addtowatchlist(request, product_id):

    obj = Watchlist.objects.filter(
        listingid=product_id, user=request.user.username)
    comments = Comment.objects.filter(listingid=product_id)
    # verificando se já foi adicionado à lista de observação
    if obj:
        # se já estiver lá, o usuário deseja removê-lo da lista de observação
        obj.delete()
        # retornando o conteúdo atualizado
        product = Listing.objects.get(id=product_id)
        added = Watchlist.objects.filter(
            listingid=product_id, user=request.user.username)
        return render(request, "auctions/viewlisting.html", {
            "product": product,
            "added": added,
            "comments": comments
        })
    else:
        # se não estiver presente, o usuário deseja adicioná-lo à lista de observação
        obj = Watchlist()
        obj.user = request.user.username
        obj.listingid = product_id
        obj.save()
        # retornando o conteúdo atualizado
        product = Listing.objects.get(id=product_id)
        added = Watchlist.objects.filter(
            listingid=product_id, user=request.user.username)
        return render(request, "auctions/viewlisting.html", {
            "product": product,
            "added": added,
            "comments": comments
        })



def categories(request):
    # lista de produtos disponíveis
    return render(request, "auctions/categories.html")

@login_required(login_url='/login')
def category(request, categ):
    # retendo todos os produtos que se enquadram nesta categoria
    categ_products = Listing.objects.filter(category=categ)
    empty = False
    if len(categ_products) == 0:
        empty = True
    return render(request, "auctions/category.html", {
        "categ": categ,
        "empty": empty,
        "products": categ_products
    })

# visualização para exibir uma lista individual
@login_required(login_url='/login')
def viewlisting(request, product_id):
    # se o usuário enviar seu lance
    comments = Comment.objects.filter(listingid=product_id)
    if request.method == "POST":
        item = Listing.objects.get(id=product_id)
        newbid = int(request.POST.get('newbid'))
        # verificar se o novo lance é maior ou igual ao lance atual
        if item.starting_bid >= newbid:
            product = Listing.objects.get(id=product_id)
            return render(request, "auctions/viewlisting.html", {
                "product": product,
                "message": "Seu lance deve ser maior do que o atual.",
                "msg_type": "danger",
                "comments": comments
            })
        # se o lance for maior do que a atualização na tabela de listagens
        else:
            item.starting_bid = newbid
            item.save()
            # salvando o lance no modelo de lance
            bidobj = Bid.objects.filter(listingid=product_id)
            if bidobj:
                bidobj.delete()
            obj = Bid()
            obj.user = request.user.username
            obj.title = item.title
            obj.listingid = product_id
            obj.bid = newbid
            obj.save()
            product = Listing.objects.get(id=product_id)
            return render(request, "auctions/viewlisting.html", {
                "product": product,
                "message": "Seu lance foi adicionado.",
                "msg_type": "success",
                "comments": comments
            })
    # acessando GET de listagem individual
    else:
        product = Listing.objects.get(id=product_id)
        added = Watchlist.objects.filter(
            listingid=product_id, user=request.user.username)
        return render(request, "auctions/viewlisting.html", {
            "product": product,
            "added": added,
            "comments": comments
        })


# visualização para painel
@login_required(login_url='/login')
def dashboard(request):
    winners = Winner.objects.filter(winner=request.user.username)
    # verificando lista de observação
    lst = Watchlist.objects.filter(user=request.user.username)
    # lista de produtos disponíveis no WinnerModel
    present = False
    prodlst = []
    i = 0
    if lst:
        present = True
        for item in lst:
            product = Listing.objects.get(id=item.listingid)
            prodlst.append(product)
    print(prodlst)
    return render(request, "auctions/dashboard.html", {
        "product_list": prodlst,
        "present": present,
        "products": winners
    })

def new_listing(request):
    if request.method == "POST":
        # item é do tipo Listagem (objeto)
        item = Listing()
        # atribuindo os dados enviados por meio do formulário ao objeto
        item.seller = request.user.username
        item.title = request.POST.get('title')
        item.description = request.POST.get('description')
        item.category = request.POST.get('category')
        item.starting_bid = request.POST.get('starting_bid')
        item.URL = request.POST.get('URL')
        # salvando os dados no banco de dados
        item.save()
        return render(request, "auctions/index.html",{"message": "Listagem feita com sucesso"})
    # se o pedido for obtido
    else:
        return render(request, "auctions/new_listing.html")


def index(request):
    # lista de produtos disponíveis
    products = Listing.objects.all()
    # verificar se há algum produto
    empty = False
    if len(products) == 0:
        empty = True
    return render(request, "auctions/index.html", {
        "products": products,
        "empty": empty
    })

def login_view(request):
    if request.method == "POST":

        # Tentativa de fazer login do usuário
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Verifique se a autenticação foi bem-sucedida
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Username e/ou password invalido."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Certifique-se de que a senha corresponda à confirmação
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Os passwords devem corresponder."
            })

        # Tentativa de criar novo usuário
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username já existente."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")

# view para comentários
@login_required(login_url='/login')
def addcomment(request, product_id):
    obj = Comment()
    obj.comment = request.POST.get("comment")
    obj.user = request.user.username
    obj.listingid = product_id
    obj.save()
    # retornando o conteúdo atualizado
    print("displaying comments")
    comments = Comment.objects.filter(listingid=product_id)
    product = Listing.objects.get(id=product_id)
    added = Watchlist.objects.filter(
        listingid=product_id, user=request.user.username)
    return render(request, "auctions/viewlisting.html", {
        "product": product,
        "added": added,
        "comments": comments
    })

# visualização para ver listas fechadas
@login_required(login_url='/login')
def closedlisting(request):
    # lista de produtos disponíveis no WinnerModel
    winners = Winner.objects.all()
    # verificar se há algum produto
    empty = False
    if len(winners) == 0:
        empty = True
    return render(request, "auctions/closedlisting.html", {
        "products": winners,
        "empty": empty
    })


# visualização quando o usuário deseja fechar o lance
@login_required(login_url='/login')
def closebid(request, product_id):
    winobj = Winner()
    listobj = Listing.objects.get(id=product_id)
    bidobj = Bid.objects.get(listingid=product_id)
    winobj.owner = request.user.username
    winobj.winner = bidobj.user
    winobj.listingid = product_id
    winobj.winprice = bidobj.bid
    winobj.title = bidobj.title
    winobj.save()
    message = "Bid Closed"
    msg_type = "success"
    # removendo do lance
    bidobj.delete()
    # removendo da lista de observação
    if Watchlist.objects.filter(listingid=product_id):
        watchobj = Watchlist.objects.filter(listingid=product_id)
        watchobj.delete()
    # removendo do comentário
    if Comment.objects.filter(listingid=product_id):
        commentobj = Comment.objects.filter(listingid=product_id)
        commentobj.delete()
    # removendo da lista
    listobj.delete()
    # recuperar a nova lista de produtos após adicionar e exibir
    # lista de produtos disponíveis no WinnerModel
    winners = Winner.objects.all()
    # verificar se há algum produto
    empty = False
    if len(winners) == 0:
        empty = True
    return render(request, "auctions/closedlisting.html", {
        "products": winners,
        "empty": empty,
        "message": message,
        "msg_type": msg_type
    })
